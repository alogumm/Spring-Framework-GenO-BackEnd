
# Foro API

Este proyecto es una API REST para un foro donde las personas pueden crear tópicos con sus dudas o sugerencias y otras personas pueden responder e interactuar. Utiliza Java y Spring Boot.

## Requisitos

- Java 17
- Spring Boot 3.2.4
- Maven

## Instalación

1. Clona este repositorio:

```bash
git clone https://github.com/tu_usuario/foro_api.git
```

2. Configura tu entorno de desarrollo Java.

3. Configura tu archivo `application.properties` con las credenciales de tu base de datos.

## Uso

Ejecuta la aplicación desde tu IDE o línea de comandos. La aplicación proporciona una API REST para crear, listar y eliminar tópicos.

## Funcionalidades

- Listar todos los tópicos.
- Crear un tópico.
- Eliminar un tópico.

## Contribuciones

Las contribuciones son bienvenidas. Por favor, abre un issue o envía un pull request para discutir cualquier cambio que te gustaría hacer.

## Licencia

Este proyecto está bajo la Licencia MIT.
