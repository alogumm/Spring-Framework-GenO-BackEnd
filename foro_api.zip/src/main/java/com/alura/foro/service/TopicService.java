
package com.alura.foro.service;

import com.alura.foro.model.Topic;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TopicService {

    private List<Topic> topics = new ArrayList<>();

    public List<Topic> getAllTopics() {
        return topics;
    }

    public Topic createTopic(Topic topic) {
        topics.add(topic);
        return topic;
    }

    public void deleteTopic(Long id) {
        topics.removeIf(topic -> topic.getId().equals(id));
    }
}
